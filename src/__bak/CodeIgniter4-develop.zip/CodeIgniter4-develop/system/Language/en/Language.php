<?php

return [
	'languageGetLineInvalidArgumentException' => 'Get line must be a string or array of strings.'
];
