<?php namespace CodeIgniter\Filters\fixtures;

class InvalidClass
{
	public function index()
	{
	    return 'bad';
	}

	//--------------------------------------------------------------------

}
